package de.hsma.ss16.oot.oware;

import static org.junit.Assert.*;

import org.junit.Test;

public class HumanPlayerTest {

	@Test
	public void testHumanPlayer() {
		
	}

}
