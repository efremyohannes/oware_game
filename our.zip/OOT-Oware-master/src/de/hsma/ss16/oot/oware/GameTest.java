package de.hsma.ss16.oot.oware;

import static org.junit.Assert.*;

import org.junit.Test;

public class GameTest {

	@Test
	public void testGame(){
	
	}

	@Test
	public void testMain() {
		fail("Not yet implemented");
	}

}
