package de.hsma.ss16.oot.oware;

import static org.junit.Assert.*;

import org.junit.Test;

public class DrawTest {


	@Test
	public void testExecute() {
		fail("Not yet implemented");
	}

	@Test
	public void testIsDrawValid() {
		fail("Not yet implemented");
	}

}
