package de.hsma.ss16.oot.oware;

import static org.junit.Assert.*;

import org.junit.Test;

public class SimulatedDrawTest {

	@Test
	public void testSimulatedDraw() {
		//SimulatedDraw p = new SimulatedDraw(null, 0);
		//int expected= 3;
		
	}

	@Test
	public void testExecute() {
		fail("Not yet implemented");
	}

	@Test
	public void testIsDrawValid() {
		SimulatedDraw p = new SimulatedDraw(null, 0);
		int expecteds = 0;
	
	}

}
